<?php get_header(); ?>

	<h1>Welcome to Olympos theme.</h1>
    <p>
        You can delete this text in index.php
    </p>

    
<?php get_footer(); ?>